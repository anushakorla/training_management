class AddRestaurantDetailToReservations < ActiveRecord::Migration
  def change
    add_reference :reservations, :restaurant_detail, index: true, foreign_key: true
  end
end
