class CreateRestaurantDetails < ActiveRecord::Migration
  def change
    create_table :restaurant_details do |t|
      t.string :name
      t.integer :number_of_tables
      t.integer :number_of_seats
      t.string :address
      t.string :street
      t.string :landmark
      t.string :place
      t.string :state
      t.integer :pincode
      t.integer :phone_number
      t.string :timings_of_restaurant
      t.string :restaurant_open

      t.timestamps null: false
    end
  end
end
