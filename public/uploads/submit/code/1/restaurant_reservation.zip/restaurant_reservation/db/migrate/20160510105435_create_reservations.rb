class CreateReservations < ActiveRecord::Migration
  def change
    create_table :reservations do |t|
      t.integer :number_of_seats
      t.string :select_tables
      t.text :table_numbers
      t.datetime :time_slot

      t.timestamps null: false
    end
  end
end
