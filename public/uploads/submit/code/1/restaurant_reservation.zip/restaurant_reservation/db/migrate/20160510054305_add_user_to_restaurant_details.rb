class AddUserToRestaurantDetails < ActiveRecord::Migration
  def change
    add_reference :restaurant_details, :user, index: true, foreign_key: true
  end
end
