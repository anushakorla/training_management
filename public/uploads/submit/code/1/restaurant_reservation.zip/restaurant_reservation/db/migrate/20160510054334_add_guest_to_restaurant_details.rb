class AddGuestToRestaurantDetails < ActiveRecord::Migration
  def change
    add_reference :restaurant_details, :guest, index: true, foreign_key: true
  end
end
