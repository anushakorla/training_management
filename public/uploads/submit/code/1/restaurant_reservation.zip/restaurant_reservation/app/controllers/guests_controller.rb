class GuestsController < ApplicationController

  

  def book_now
    ConfirmationMailer.send_confirmation_user(@user).deliver
    ConfirmationMailer.send_confirmation_guest(@guest).deliver
   end

  def new
    @guest = Guest.new
  end

  def create
    @guest = Guest.new(guest_params)
    @restaurant_detail = RestaurantDetail.find(cookies[:restaurant_detail_id])
    @reservation = @restaurant_detail.reservations.find(cookies[:reservation_id])
    respond_to do |format|
      if @guest.save
        @restaurant_detail.update(guest_id: @guest.id)
        @reservation.update(guest_id: @guest.id)
        format.html { redirect_to confirmation_page_guests_path, notice: 'Guest was successfully logged in' }
        format.json { render :confirmation_page, status: :created, location: @guest }
      else
        format.html { render :new }
        format.json { render json: @guest.errors, status: :unprocessable_entity }
      end
    end
  end
  def confirmation_page
     @restaurant_detail = RestaurantDetail.find(cookies[:restaurant_detail_id])
     @reservation = @restaurant_detail.reservations.find(cookies[:reservation_id])
  end

  


  private
    
    def set_guest
      @guest = Guest.find(params[:id])
    end

    
    def guest_params
      params.require(:guest).permit(:name, :email)
    end
end
