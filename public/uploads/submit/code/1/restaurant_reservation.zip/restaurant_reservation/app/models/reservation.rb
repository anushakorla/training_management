class Reservation < ActiveRecord::Base

	has_many :users, dependent: :destroy
	belongs_to :restaurant_detail
	has_many :guests, dependent: :destroy
	serialize :table_numbers,Array
end
