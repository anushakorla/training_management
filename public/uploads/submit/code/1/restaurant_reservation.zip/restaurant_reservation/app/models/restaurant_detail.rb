class RestaurantDetail < ActiveRecord::Base
	 validates_numericality_of :phone_number, :on => :create
	 has_many :users, dependent: :destroy
	 has_many :reservations, dependent: :destroy
	 has_many :guests, dependent: :destroy
end
