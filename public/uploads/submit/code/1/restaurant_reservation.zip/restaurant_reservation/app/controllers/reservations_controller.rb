class ReservationsController < ApplicationController
  before_action :set_reservation, only: [:show, :edit, :update, :destroy]


  def show
  end


 
  def new
    restaurant_detail = RestaurantDetail.find(params[:restaurant_detail_id])
    @reservation =restaurant_detail.reservations.build
  end

  def create
    restaurant_detail = RestaurantDetail.find(params[:restaurant_detail_id])
    @reservation = restaurant_detail.reservations.create(reservation_params)
    cookies[:restaurant_detail_id] = restaurant_detail.id
    cookies[:reservation_id] = @reservation.id
    respond_to do |format|
      if @reservation.save
        format.html { redirect_to [@reservation.restaurant_detail,@reservation], notice: 'Reservation was successfully created.' }
        format.json { render :show, status: :created, location: @reservation }
      else
        format.html { render :new }
        format.json { render json: @reservation.errors, status: :unprocessable_entity }
      end
    end
  end

  def number_of_tables
    restaurant_detail = RestaurantDetail.find(params[:restaurant_detail_id])
    @reservation = restaurant_detail.reservations.last
    @reservation.update(table_numbers: params[:tables])
  end


  private
    
    def set_reservation
    restaurant_detail = RestaurantDetail.find(params[:restaurant_detail_id])
    @reservation = restaurant_detail.reservations.find(params[:id])
    end

   
    def reservation_params
      params.require(:reservation).permit(:number_of_seats, :select_tables, :number_of_tables,:time_slot)
    end
end
