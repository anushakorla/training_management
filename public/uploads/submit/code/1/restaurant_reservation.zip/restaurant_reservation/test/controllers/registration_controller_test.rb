require 'test_helper'

class RegistrationControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
