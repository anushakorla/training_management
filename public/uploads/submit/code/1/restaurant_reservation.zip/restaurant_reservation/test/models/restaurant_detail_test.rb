require 'test_helper'

class RestaurantDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
