require 'test_helper'

class RestaurantDetailsControllerTest < ActionController::TestCase
  setup do
    @restaurant_detail = restaurant_details(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:restaurant_details)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create restaurant_detail" do
    assert_difference('RestaurantDetail.count') do
      post :create, restaurant_detail: { address: @restaurant_detail.address, landmark: @restaurant_detail.landmark, name: @restaurant_detail.name, number_of_seats: @restaurant_detail.number_of_seats, number_of_tables: @restaurant_detail.number_of_tables, phone_number: @restaurant_detail.phone_number, pincode: @restaurant_detail.pincode, place: @restaurant_detail.place, restaurant_open: @restaurant_detail.restaurant_open, state: @restaurant_detail.state, street: @restaurant_detail.street, timings_of_restaurant: @restaurant_detail.timings_of_restaurant }
    end

    assert_redirected_to restaurant_detail_path(assigns(:restaurant_detail))
  end

  test "should show restaurant_detail" do
    get :show, id: @restaurant_detail
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @restaurant_detail
    assert_response :success
  end

  test "should update restaurant_detail" do
    patch :update, id: @restaurant_detail, restaurant_detail: { address: @restaurant_detail.address, landmark: @restaurant_detail.landmark, name: @restaurant_detail.name, number_of_seats: @restaurant_detail.number_of_seats, number_of_tables: @restaurant_detail.number_of_tables, phone_number: @restaurant_detail.phone_number, pincode: @restaurant_detail.pincode, place: @restaurant_detail.place, restaurant_open: @restaurant_detail.restaurant_open, state: @restaurant_detail.state, street: @restaurant_detail.street, timings_of_restaurant: @restaurant_detail.timings_of_restaurant }
    assert_redirected_to restaurant_detail_path(assigns(:restaurant_detail))
  end

  test "should destroy restaurant_detail" do
    assert_difference('RestaurantDetail.count', -1) do
      delete :destroy, id: @restaurant_detail
    end

    assert_redirected_to restaurant_details_path
  end
end
