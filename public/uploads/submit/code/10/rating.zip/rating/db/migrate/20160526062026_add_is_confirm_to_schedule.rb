class AddIsConfirmToSchedule < ActiveRecord::Migration
  def change
  	add_column :schedules, :is_confirm, :boolean, default: false
  end
end
