class CommentsController < ApplicationController
  before_action :set_comment, only: [:show, :edit, :update, :destroy]

  
  def view
    
  end

  def new
    @comment = Comment.new
  end
  
  def create
    @comment = current_user.comments.build(comment_params)
     respond_to do |format|
      if @comment.save
        @comments = Comment.all
        format.html {redirect_to questions_path}
        flash[:success] = 'Comment was successfully created.'
        format.json
        format.js 
      else
        format.html {render :new}
        format.json
        format.js
      end
    end
    end

  def destroy
   respond_to do |format|
    @comment.destroy
      format.html {redirect_to overall_customer_ratings_path}
      flash[:success] =  'Comment was successfully destroyed.' 
      format.json
      format.js
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_comment
      @comment = Comment.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def comment_params
      params.require(:comment).permit(:comment,:user_id)
    end
end
