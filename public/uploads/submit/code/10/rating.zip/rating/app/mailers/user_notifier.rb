class UserNotifier < ApplicationMailer
	default :from => 'rubyeffect@gmail.com'
    #sending invitation mail to user
	def send_invitation_email(user)
		@user = user
		mail( :to => @user.email,
		:subject => 'Invitation for online meeting.')
	end
end
