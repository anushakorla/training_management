class QuestionsController < ApplicationController
  before_action :set_question, only: [:show, :edit, :update, :destroy]

  def index
    @questions = Question.all
    @comment = Comment.new
    if user_signed_in?
      @comments = Comment.where(user_id: current_user.id)
    end
  end

  def show
  end

  def new
    @question = Question.new
    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @question }
      format.js
    end
  end

  def edit
    @question = Question.find(params[:id])
    respond_to do |format|
        format.html
        format.js
    end
  end

  def create
    @question = Question.new(question_params)

      respond_to do |format|
       if @question.save
        format.html { redirect_to questions_url}
        flash[:success] = 'Question was successfully created.'
        format.json { render json: @question, status: :created, location: @question }
        format.js
      else
        format.html { render action: "new" }
        format.json { render json: @question.errors, status: :unprocessable_entity }
        format.js
      end
    end
  end

  def update
     respond_to do |format|
      if @question.update(question_params)
         format.html { redirect_to @question }
        flash[:success] = 'Question was successfully updated.' 
        format.json { head :no_content }
        format.js
      else
        format.html { render action: "edit" }
        format.json { render json: @question.errors, status: :unprocessable_entity }
        format.js
      end
    end
  end

 
  def destroy
    respond_to do |format|
     @question.destroy
      format.html { redirect_to questions_url }
      flash[:success] = 'Question was successfully destroyed.' 
      format.json { head :no_content }
      format.js
    end
  end

  def rate
    @rates = Rate.where(rater_id: current_user.id)
    count = 0
    total = 0
    @rates.each do |rate|
      total = total + rate.stars
      if rate.stars < 3
        count = count + 1
      end
    end
    if count > 1 
      AdminNotifier.feedback_email(@admin).deliver
      flash[:success] = "The Rating was submitted successfully." 
    end
    if total/@rates.count
      UserNotifier.send_invitation_email(current_user).deliver
      flash[:success] = "The Rating was submitted successfully." 
    end
     redirect_to questions_path
  end

  def reject
    @admin = Admin.last
    RejectNotifier.user_reject_email(@admin).deliver_now
  end

  



  private
    # Use callbacks to share common setup or constraints between actions.
    def set_question
      @question = Question.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def question_params
      params.require(:question).permit(:question)
    end

end
