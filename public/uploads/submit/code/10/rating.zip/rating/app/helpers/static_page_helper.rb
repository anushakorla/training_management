module StaticPageHelper
end
