class SchedulesController < ApplicationController

    def new
     if user_signed_in?
      @schedule = Schedule.new
     else
      redirect_to new_user_session_path
     end
	end

    def create
    	@user = current_user
    	@schedule = current_user.schedules.build(schedule_params)
    	@admin = Admin.last
    	if @schedule.save
    		ScheduleNotifierToAdmin.admin_schedule_email(@admin, @schedule).deliver_now
    		flash[:success] = "The schedule meeting was sent successfully to admin."
    		code = SecureRandom.hex(3)
            @schedule.update(code: code)
		    ScheduleNotifierToUser.user_schedule_email(@user, @schedule, code).deliver_now
		    flash[:success] = "The schedule meeting was sent successfully to customer."

    		redirect_to questions_path
	    else
	    	render 'new'
	    end
	end
	def confirmation
		if params[:code].present?
			schedule = Schedule.where(code: params[:code]).first
			if schedule.present?
				if schedule.is_confirm
		      flash[:danger] = "Coupon code is already used."
				else
  				schedule.update(is_confirm: true)
		      flash[:success] = "Coupon code confirmed successfully."
  			end
 			else
		      flash[:danger] = "Invalid Coupon code."
			end
		end
      redirect_to questions_path
	end

	private

	def schedule_params
    params.require(:schedule).permit(:date, :code, :user_id)
    end
end
