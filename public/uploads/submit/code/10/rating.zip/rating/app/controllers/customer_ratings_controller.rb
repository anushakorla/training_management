class CustomerRatingsController < ApplicationController
  def rating
    @users = User.all
    @one_three_users = []
    @four_seven_users = []
    @eight_ten_users = []
    
    @users.each do |user|
      total = 0
      @rates = Rate.where(rater_id: user.id)
      @rates.each do |rate|
        total = total + rate.stars
      end
      average = total/Question.count
      if (average <= 3)
        @one_three_users << user
      elsif  (average > 3 && average <= 7)
        @four_seven_users << user
      elsif (average > 7 && average <= 10)
        @eight_ten_users << user
      end
    end
  end

  def overall
  	@questions = Question.all
  	@comments = Comment.where(user_id: params[:user_id])
  	@rates = Rate.where(rater_id: params[:user_id]) 
  end
  
  def meeting
    @users = User.all
  end
end
