class ScheduleNotifierToUser < ApplicationMailer
	default :from => 'rubyeffect@gmail.com'
	# sending meeting schedule to user
	def user_schedule_email(user, schedule, code)
		@user = user
		@schedule = schedule
		@code = code
		mail( :to => @user.email,
		:subject => 'Online meeting Shedule.')
    end
end
