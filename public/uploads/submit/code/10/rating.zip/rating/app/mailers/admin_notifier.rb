class AdminNotifier < ApplicationMailer
	default :from => 'rubyeffect@gmail.com'
  # sending feedback review to admin when the average rating less than three
    def feedback_email(rater)
       @rater = rater
       @admin = Admin.first
       mail( :to => @admin.email,
       :subject => "Feedback Review")
    end
end
