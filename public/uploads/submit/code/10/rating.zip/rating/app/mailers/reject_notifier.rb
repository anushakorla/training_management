class RejectNotifier < ApplicationMailer
	default :from => 'rubyeffect@gmail.com'
	# sending rejected information to admin
	def user_reject_email(admin)
		@admin = admin
		mail( :to => @admin.email,
		:subject => 'Meeting Rejected..')
    end
end
