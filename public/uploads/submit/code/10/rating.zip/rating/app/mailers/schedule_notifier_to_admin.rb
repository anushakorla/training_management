class ScheduleNotifierToAdmin < ApplicationMailer
  default :from => 'rubyeffect@gmail.com'
    # sending meeting Schedule to admin
	def admin_schedule_email(admin, schedule)
		@schedule = schedule
		@admin = admin
		mail( :to => @admin.email,
		:subject => 'Online Meeting Schedule.')
    end
end
