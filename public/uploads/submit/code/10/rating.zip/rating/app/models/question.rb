class Question < ActiveRecord::Base
	ratyrate_rateable "question"
	belongs_to :admin
	has_many :users
	has_many :comments
	validates :question, presence: true
end
