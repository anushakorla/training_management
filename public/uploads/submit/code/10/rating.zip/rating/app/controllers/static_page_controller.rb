class StaticPageController < ApplicationController
  def home
  end
end
