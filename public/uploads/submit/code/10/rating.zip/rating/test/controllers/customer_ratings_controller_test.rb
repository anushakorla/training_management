require 'test_helper'

class CustomerRatingsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
