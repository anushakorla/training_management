require 'test_helper'

class ScheduleNotifierToAdminTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
