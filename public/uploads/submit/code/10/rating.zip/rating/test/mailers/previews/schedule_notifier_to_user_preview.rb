# Preview all emails at http://localhost:3000/rails/mailers/schedule_notifier_to_user
class ScheduleNotifierToUserPreview < ActionMailer::Preview

end
