# Preview all emails at http://localhost:3000/rails/mailers/reject_notifier
class RejectNotifierPreview < ActionMailer::Preview

end
