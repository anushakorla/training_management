require 'test_helper'

class ScheduleControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
